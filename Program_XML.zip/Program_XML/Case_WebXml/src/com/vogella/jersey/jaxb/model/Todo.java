package com.vogella.jersey.jaxb.model;

import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
// JAX-RS supports an automatic mapping from JAXB annotated class to XML and JSON
// Isn't that cool?
public class Todo {
        private String summary;
        private String summary1;
        private String description;
        private String description1;
        public String getSummary1() {
                return summary1;
        }
        public void setSummary1(String summary1) {
                this.summary1 = summary1;
        }
        public String getSummary() {
            return summary;
    }
    public void setSummary(String summary) {
            this.summary = summary;
    }
        public String getDescription1() {
                return description1;
        }
        public void setDescription1(String description1) {
                this.description1 = description1;
        }
        public String getDescription() {
            return description;
    }
    public void setDescription(String description) {
            this.description = description;
    }


}